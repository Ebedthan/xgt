use crate::utils::SearchField;
use std::fmt;

/// Percent-encode a query string value.
/// Encodes all characters except unreserved URI characters (A-Z a-z 0-9 - _ . ~).
/// Spaces become %20 (not +), which is correct for query parameter values
/// in application/x-www-form-urlencoded within a URI path.
fn encode_query_value(s: &str) -> String {
    s.chars()
        .flat_map(|c| match c {
            'A'..='Z' | 'a'..='z' | '0'..='9' | '-' | '_' | '.' | '~' => vec![c],
            _ => format!("%{:02X}", c as u32).chars().collect(),
        })
        .collect()
}

#[derive(Debug, Clone)]
pub enum GtdbApiRequest {
    Taxon {
        name: String,
        kind: TaxonEndPoint,
        limit: Option<u32>,
        is_reps_only: Option<bool>,
        // release: not supported by the API, added when/if support is confirmed
    },
    Search {
        query: String,
        page: u16,
        items_per_page: u32,
        sort_by: String,
        sort_desc: bool,
        search_field: SearchField,
        filter_text: String,
        gtdb_species_rep_only: bool,
        ncbi_type_material_only: bool,
        output_format: String,
        // release: not supported by the API, added when/if support is confirmed
    },
    Genome {
        accession: String,
        request_type: GenomeRequestType,
        release: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Copy)]
pub enum GenomeRequestType {
    Metadata,
    TaxonHistory,
    Card,
}

impl fmt::Display for GenomeRequestType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            GenomeRequestType::Card => "card",
            GenomeRequestType::Metadata => "metadata",
            GenomeRequestType::TaxonHistory => "taxon-history",
        };
        write!(f, "{}", s)
    }
}

impl std::str::FromStr for GenomeRequestType {
    type Err = ();

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "metadata" => Ok(GenomeRequestType::Metadata),
            "taxon-history" => Ok(GenomeRequestType::TaxonHistory),
            "card" => Ok(GenomeRequestType::Card),
            _ => Err(()),
        }
    }
}

#[derive(Debug, Clone)]
pub enum TaxonEndPoint {
    Name,
    Search,
    SearchAll,
    Genomes,
}

impl GtdbApiRequest {
    pub fn to_url(&self) -> String {
        match self {
            GtdbApiRequest::Taxon {
                name,
                kind,
                limit,
                is_reps_only,
            } => {
                // Taxon endpoints do not support ?release=, always serves latest
                match kind {
                    TaxonEndPoint::Name => {
                        format!(
                            "https://gtdb-api.ecogenomic.org/taxon/{}",
                            encode_query_value(name)
                        )
                    }
                    TaxonEndPoint::Search => format!(
                        "https://gtdb-api.ecogenomic.org/taxon/search/{}?limit={}",
                        encode_query_value(name),
                        limit.unwrap_or(100)
                    ),
                    TaxonEndPoint::SearchAll => format!(
                        "https://gtdb-api.ecogenomic.org/taxon/search/{}/all-releases?limit={}",
                        encode_query_value(name),
                        limit.unwrap_or(100)
                    ),
                    TaxonEndPoint::Genomes => format!(
                        "https://gtdb-api.ecogenomic.org/taxon/{}/genomes?sp_reps_only={}",
                        encode_query_value(name),
                        is_reps_only.unwrap_or(false)
                    ),
                }
            }

            GtdbApiRequest::Search {
                query,
                page,
                items_per_page,
                sort_by,
                sort_desc,
                search_field,
                filter_text,
                gtdb_species_rep_only,
                ncbi_type_material_only,
                output_format,
            } => {
                let mut url = format!(
                    "https://gtdb-api.ecogenomic.org/search/gtdb{}?",
                    if output_format == "json" {
                        String::new()
                    } else {
                        format!("/{}", output_format)
                    }
                );
                let mut params = vec![
                    format!("search={}", encode_query_value(query)),
                    format!("page={}", page),
                    format!("itemsPerPage={}", items_per_page),
                    format!("searchField={}", search_field.to_string()),
                ];

                if !sort_by.is_empty() {
                    params.push(format!("sortBy={}", sort_by));
                }

                if *sort_desc {
                    params.push("sortDesc=true".into());
                }

                if !filter_text.is_empty() {
                    params.push(format!("filterText={}", encode_query_value(filter_text)));
                }

                if *gtdb_species_rep_only {
                    params.push("gtdbSpeciesRepOnly=true".into());
                }

                if *ncbi_type_material_only {
                    params.push("ncbiTypeMaterialOnly=true".into());
                }

                url.push_str(&params.join("&"));
                url
            }

            GtdbApiRequest::Genome {
                accession,
                request_type,
                release,
            } => {
                let base = format!(
                    "https://gtdb-api.ecogenomic.org/genome/{}/{}",
                    accession, request_type
                );
                // Append release only for card and metadata; taxon-history
                // is inherently cross-release
                match request_type {
                    GenomeRequestType::Card | GenomeRequestType::Metadata => match release {
                        Some(r) => format!("{}?release={}", base, r),
                        None => base,
                    },
                    GenomeRequestType::TaxonHistory => base,
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::str::FromStr;

    #[test]
    fn test_display_genome_request_type() {
        assert_eq!(GenomeRequestType::Metadata.to_string(), "metadata");
        assert_eq!(GenomeRequestType::TaxonHistory.to_string(), "taxon-history");
        assert_eq!(GenomeRequestType::Card.to_string(), "card");
    }

    #[test]
    fn test_from_str_valid_inputs() {
        assert_eq!(
            GenomeRequestType::from_str("metadata").unwrap(),
            GenomeRequestType::Metadata
        );
        assert_eq!(
            GenomeRequestType::from_str("taxon-history").unwrap(),
            GenomeRequestType::TaxonHistory
        );
        assert_eq!(
            GenomeRequestType::from_str("card").unwrap(),
            GenomeRequestType::Card
        );
    }

    #[test]
    fn test_from_str_invalid_input() {
        assert!(GenomeRequestType::from_str("invalid").is_err());
        assert!(GenomeRequestType::from_str("").is_err());
        assert!(GenomeRequestType::from_str("CARD").is_err()); // case sensitive
    }

    #[test]
    fn test_taxon_name_url() {
        let req = GtdbApiRequest::Taxon {
            name: "Bacillus".into(),
            kind: TaxonEndPoint::Name,
            limit: None,
            is_reps_only: None,
        };
        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/taxon/Bacillus"
        );
    }

    #[test]
    fn test_taxon_genomes_url() {
        let req = GtdbApiRequest::Taxon {
            name: "Bacillus".into(),
            kind: TaxonEndPoint::Genomes,
            limit: None,
            is_reps_only: Some(true),
        };
        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/taxon/Bacillus/genomes?sp_reps_only=true"
        );
    }

    #[test]
    fn test_search_api_url_csv() {
        let req = GtdbApiRequest::Search {
            query: "Bacillus".into(),
            page: 2,
            items_per_page: 500,
            sort_by: "name".into(),
            sort_desc: true,
            search_field: SearchField::GtdbTax,
            filter_text: "species".into(),
            gtdb_species_rep_only: true,
            ncbi_type_material_only: true,
            output_format: "csv".into(),
        };

        let url = req.to_url();
        assert!(url.starts_with("https://gtdb-api.ecogenomic.org/search/gtdb/csv?"));
        assert!(url.contains("search=Bacillus"));
        assert!(url.contains("sortBy=name"));
        assert!(url.contains("sortDesc=true"));
        assert!(url.contains("searchField=gtdb_tax"));
        assert!(url.contains("gtdbSpeciesRepOnly=true"));
        assert!(url.contains("ncbiTypeMaterialOnly=true"));
    }

    #[test]
    fn test_genome_card_request_url() {
        let req = GtdbApiRequest::Genome {
            accession: "GCF_000005845.2".into(),
            request_type: GenomeRequestType::Card,
            release: None,
        };

        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/genome/GCF_000005845.2/card"
        );
    }

    #[test]
    fn test_genome_card_with_release() {
        let req = GtdbApiRequest::Genome {
            accession: "GCF_000005845.2".into(),
            request_type: GenomeRequestType::Card,
            release: Some("R214".into()),
        };
        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/genome/GCF_000005845.2/card?release=R214"
        );
    }

    #[test]
    fn test_genome_card_without_release() {
        let req = GtdbApiRequest::Genome {
            accession: "GCF_000005845.2".into(),
            request_type: GenomeRequestType::Card,
            release: None,
        };
        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/genome/GCF_000005845.2/card"
        );
    }

    #[test]
    fn test_genome_taxon_history_ignores_release() {
        // taxon-history is always cross-release; release param is never appended
        let req = GtdbApiRequest::Genome {
            accession: "GCF_000005845.2".into(),
            request_type: GenomeRequestType::TaxonHistory,
            release: Some("R214".into()),
        };
        assert_eq!(
            req.to_url(),
            "https://gtdb-api.ecogenomic.org/genome/GCF_000005845.2/taxon-history"
        );
    }

    // Add a new test for the None default:
    #[test]
    fn test_taxon_search_default_limit() {
        let req = GtdbApiRequest::Taxon {
            name: "Bacillus".into(),
            kind: TaxonEndPoint::Search,
            limit: None,
            is_reps_only: None,
        };
        assert!(req.to_url().contains("limit=100"));
    }

    #[test]
    fn test_taxon_search_all_releases_default_limit() {
        let req = GtdbApiRequest::Taxon {
            name: "Bacillus".into(),
            kind: TaxonEndPoint::SearchAll,
            limit: None,
            is_reps_only: None,
        };
        assert!(req.to_url().contains("limit=100"));
    }

    #[test]
    fn test_encode_query_value_space() {
        assert_eq!(
            encode_query_value("s__Escherichia coli"),
            "s__Escherichia%20coli"
        );
    }

    #[test]
    fn test_encode_query_value_no_encoding_needed() {
        assert_eq!(encode_query_value("g__Escherichia"), "g__Escherichia");
    }

    #[test]
    fn test_encode_query_value_underscore_preserved() {
        // Double underscore (GTDB rank prefix) must not be encoded
        assert_eq!(encode_query_value("s__Homo_sapiens"), "s__Homo_sapiens");
    }

    #[test]
    fn test_encode_query_value_special_chars() {
        assert_eq!(encode_query_value("test&query=1"), "test%26query%3D1");
    }

    #[test]
    fn test_search_url_with_species_name_encodes_space() {
        let req = GtdbApiRequest::Search {
            query: "s__Escherichia coli".into(),
            search_field: "ncbi_org".to_string().into(),
            gtdb_species_rep_only: false,
            ncbi_type_material_only: true,
            output_format: "json".into(),
            page: 1,
            items_per_page: 1000,
            sort_by: "".into(),
            sort_desc: false,
            filter_text: "".into(),
        };
        let url = req.to_url();
        assert!(
            url.contains("search=s__Escherichia%20coli"),
            "space in species name must be percent-encoded: {url}"
        );
        assert!(
            !url.contains("search=s__Escherichia coli"),
            "raw space must not appear in URL: {url}"
        );
    }
}
